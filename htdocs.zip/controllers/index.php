<?php

require VIEW_PATH . "index.view.php";